# Windows installation

Verify the ZIP sidecar SHA-256 through a trusted transfer. Extract to a staging folder.
Verify every manifest file length/hash before loading it. Validate all profiles with
schemas/callout_profile.schema.json and reference/live_callouts.py. Load profile
sources in manifest source_priority order (profiles/0, then profiles/1 if supplied).
Activate atomically between fights and retain the last working bundle.

reference/combat_log_core.py and reference/live_callouts.py are dependency-free
examples of the exact server matcher. ObservedCalloutEngine.start accepts an object
with encounter_id, difficulty, session_id, attempt_id, attempt, encounter_name and
log_start_timestamp attributes. Map its MECHANIC_CALLOUT output to the wire
MECHANIC_OBSERVED identifiers; never send its speech text. Read PROTOCOL.md.

Configure HTTPS, guild ID and the existing private guild live token. No Discord
credentials are needed. On Carter select /logs live mode:on source:companion and
join voice with /carter join. The old bulk Test button does not test this feed.
